Đây là placeholder. Mô hình 3D nón bảo hiểm cần được dựng trong Fusion 360.
Bạn có thể sử dụng hướng dẫn trước để vẽ mô hình bằng Sketch + Revolve hoặc yêu cầu mình tạo file .F3D.